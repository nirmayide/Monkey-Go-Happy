var monkey , monkey_running;
var banana ,bananaImage, obstacle, obstacleImage;
var foodGroup, obstaclesGroup;
var score;

function preload(){
  
  
  monkey_running = loadAnimation("monkey_0.png", "monkey_1.png", "monkey_2.png", "monkey_3.png", "monkey_4.png", "monkey_5.png", "monkey_6.png", "monkey_7.png", "monkey_8.png")
  
  bananaImage = loadImage("banana.png");
  obstaceImage = loadImage("obstacle.png");
 
}



function setup() {
  createCanvas (600,200);
  
  var survivalTime = 0;
  
  monkey = createSprite(80,315,20,20);
  monkey.addAnimation("moving",monkey_running);
  monkey.scale = 0.1;
  
  ground = createSprite(400,350,900,10);
  ground.velocityX = -0.4;
  ground.x = ground.width/2;
  //console.log(ground.x);
  
  foodGroup = new Group();
  obstaclesGroup = new Group();
  
  score = 0;
  
}


function draw() {
  background(255);
  
  if (keyDown("space")){
    monkey.velocityY = 6;
  }
  
  monkey.velocityY = monkey.velocityY + 0.6;
  
  if (ground.x<0){
    ground.x = ground.width/2;
  }
  
  monkey.collide(ground);
  spawnFood();
  spawnObstacles();
  
  
  drawSprites();
  
  stroke("white");
  textSize(20);
  fill("white");
  text("Score:"+ score,500,50);
  
  if(obstaclesGroup.isTouching(monkey)){
    ground.velocityX = 0;
    monkey.velocityY = 0;
    obstaclesGroup.setVelocityXEach(0);
    foodGroup.setVelocityXEach(0);
    obstaclesGroup.setLifetimeEach(-1);
    foodGroup.setLifetimeEach(-1);
  }
  
    stroke("black");
    textSize(20);
    fill("black");
    survivalTime = Math.ceil(frameCount/frameRate());
    text("Survival Time:"+ survivalTime, 100,50);
}

function spawnFood(){
  if(frameCount%80 === 0){
    var banana = createSprite(80,315,20,20);
    banana.addImage("banana", bananaImage);
    banana.velocityX = -1;
    banana.velocityY = 0;
    banana.y = Math.round(random(120,200));
    banana.lifetime = 320;
    banana.scale = 0.1;
    foodGroup.add(banana);
  }
}

function spawnObstacles(){
  if (frameCount%300 === 0){
    var obstacle = createSprite(100,100,20,20);
    obstacle.addImage("obstacles", obstacleImage);
    obstacle.velocityX = -(2+score/100);
    obstacle.velocityY = 0;
    obstacle.x = Math.round(random(200,600));
    obstacle.lifetime = 320;
    obstaclesGroup.add(obstacle);
  }
}